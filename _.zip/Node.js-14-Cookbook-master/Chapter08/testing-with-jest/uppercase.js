module.exports = (string) => {
  return string.toUpperCase();
};

