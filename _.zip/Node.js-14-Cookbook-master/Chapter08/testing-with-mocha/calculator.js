module.exports.add = (number1, number2) => {
    return number1 + number2;
};

module.exports.subtract = (number1, number2) => {
    return number1 - number2;
};

module.exports.multiply = (number1, number2) => {
    return number1 * number2;
};

module.exports.divide = (number1, number2) => {
    return number1 / number2;
};

