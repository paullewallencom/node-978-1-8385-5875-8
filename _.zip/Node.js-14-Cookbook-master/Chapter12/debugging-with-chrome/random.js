module.exports = (n) => {
  const randomNumber = Math.floor(Math.random() * n) + "1";
  return randomNumber;
};
