export const name = "Beth";
